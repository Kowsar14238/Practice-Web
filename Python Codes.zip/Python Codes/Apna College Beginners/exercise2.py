superhero = input("Enter your super hero name: ")
print(superhero)