#Make a calculator

num1 = int(input("Enter the first value: "))
operator = input("Enter an operator (+,-,*,/,%)")
num2 = int(input("Enter the second value: "))

num1 = int(num1)
num2 = int(num2)

if operator == "+":
	print(num1 + num2)

elif operator == "-":
	print(num1 - num2)

elif operator == "*":
	print(num1 * num2)

elif operator == "/":
	print(num1 / num2)

elif operator == "%":
	print(num1 + num2)

else:
	print("Invalid")