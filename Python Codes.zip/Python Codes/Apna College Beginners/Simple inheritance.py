class Mother:
    def mother(self):
        print("Amena Begum")

class Father:
    def father(self):
        print("Abdullah")
 
class Son(Mother, Father):
    def parents(self):
        print("Father :", self.fathername)
        print("Mother :", self.mothername)
 

s = Son()
s.parents()