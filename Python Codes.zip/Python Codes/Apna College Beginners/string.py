name = "Tony Stark"

print(name.upper())
print(name.lower())
print(name.find('S'))
print(name.find('s'))#Not in string
print(name.find('Stark'))
print(name.find('stark'))#Not in string
print(name.replace('Tony Stark', 'Iron man'))
print(name.replace('Stark','Batman'))
print(name.replace('T','M'))

print(name)