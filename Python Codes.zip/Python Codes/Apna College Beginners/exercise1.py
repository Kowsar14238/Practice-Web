f_name 	  = "Tony "
l_name 	  = "Stark"
age		  = 51
is_genius = True

print(f_name+" "+l_name)
print(age)
print(is_genius)