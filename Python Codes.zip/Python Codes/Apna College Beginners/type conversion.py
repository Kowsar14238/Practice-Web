old_age = input("Your old age: ")
new_age = int(old_age) + 2

print(new_age)