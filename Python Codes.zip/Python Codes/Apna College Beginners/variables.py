name = "Nothing"
age =  22

print(name)
print(22)