age = 19

if age>= 18:
	print("You are an adult")
	print("You can vote")
elif age<18 and age>3:
	print("You are in School")
else:
	print("You are a child")

print("Thank you")