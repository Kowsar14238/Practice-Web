age = 16

if age>= 18:
	print("You are an adult")
	print("You can vote")

print("Thank you")