'''
num1 = int(input("Enter the value: "))
num2 = int(input("Enter the value: "))

sum = num1 + num2

print(sum) '''

num1 = input("Value 1: ")
num2 = input("Value 2: ")

sum = int(num1) + int(num2)
print(sum)