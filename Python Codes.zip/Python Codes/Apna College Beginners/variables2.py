name = "Me"
age  = 24
is_adult = False

print(is_adult)