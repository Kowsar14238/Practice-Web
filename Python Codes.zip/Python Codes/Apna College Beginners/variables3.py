first_name = "Mr."
last_name  = "Faltu"
age		   = 19
is_adult   = True

print(first_name+ " "+last_name)
print(age)
print(is_adult)