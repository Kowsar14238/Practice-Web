name = input("Enter you name: ")
print("Hello" + name)