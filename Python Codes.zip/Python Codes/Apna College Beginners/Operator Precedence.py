result1 = 2 + 3 * 5
result2 = (2 + 3) * 5
result3 = 2 + 3 / 5
print(result1, result2, result3)