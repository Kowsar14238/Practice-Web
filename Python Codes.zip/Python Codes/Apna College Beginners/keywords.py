name = "Tony Stark"

print('T' in name)
print('m' in name)