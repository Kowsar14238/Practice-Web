i = 5
i = i + 2
#i += 2

print(i)